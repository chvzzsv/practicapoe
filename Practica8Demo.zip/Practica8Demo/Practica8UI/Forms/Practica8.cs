﻿
//using Microsoft.Data.SqlClient;
//using System.Data.SqlClient;
using SqlConnection = System.Data.SqlClient.SqlConnection;
using SqlCommand = Microsoft.Data.SqlClient.SqlCommand;

namespace Practica8UI.Forms
{
    public partial class Practica8 : Form
    {
        public Practica8()
        {
            InitializeComponent();
        }

        SqlConnection conexion = new SqlConnection("Data Source=LAPTOP-CHAVEZ;Initial Catalog=EmpresaPOE;Integrated Security=True; TrustServerCertificate=True");

        public void completarTabla()
        {

        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            conexion.Open();

            string consulta = "INSERT INTO EMPLEADOS VALUES" + "(" + txtID.Text + ", '" +txtNombre.Text + "','" + txtDireccion.Text + "')";

            SqlCommand comando = new SqlCommand(consulta, conexion);

            comando.ExecuteNonQuery();

            conexion.Close();
        }
    }
}
